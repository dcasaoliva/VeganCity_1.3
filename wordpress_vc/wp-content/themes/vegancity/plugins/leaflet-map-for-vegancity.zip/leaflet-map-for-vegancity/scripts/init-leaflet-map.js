// initialize the function declared in construct-leaflet-map.js in document head
WPLeafletMapPlugin.init();